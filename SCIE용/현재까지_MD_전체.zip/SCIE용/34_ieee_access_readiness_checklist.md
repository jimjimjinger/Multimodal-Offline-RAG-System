# IEEE Access 원고 준비 체크리스트

## 목적

이 문서는 IEEE Access 1차 제출본 작성에 필요한 작업의 완료 여부와 제출 전에 저자가 직접 확인해야 할 항목을 구분한다.

## 현재 완료된 항목

| 항목 | 상태 | 관련 파일 |
|---|---|---|
| 연구 질문 및 G1/G2/G3/G4 비교군 정의 | 완료 | `04_research_questions.md`, `05_experiment_groups.md` |
| 70개 질의셋과 정답 텍스트·이미지·단계 라벨 구성 | 완료 | `excel/03_question_set_70.xlsx` |
| 평가 지표와 관련성 판정 기준 정의 | 완료 | `06_metrics.md`, `27_evaluation_protocol.md` |
| G4 단계 맥락표와 질문 기반 단계 추정 구현 | 완료 | `excel/11_stage_context_map_manual.xlsx`, `29_stage_classifier_results.md`, `33_context_map_protocol.md` |
| G1/G2/G3/G4 검색 성능 최종 평가 | 완료 | `15_g1_g2_g3_g4_results.md` |
| 최신 검색 수치 통일 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| G4 개선 사례와 실패 사례 분석 | 완료 | `16_g4_case_analysis.md` |
| Algorithm 1의 기호·가중치·임계값·fallback 설명 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| 가중치 선택과 제한적 grid search의 내부 평가 한계 설명 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| BBox 후보 필터와 SigLIP 의미 순위화의 역할 분리 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| BBox/SigLIP 비교 결과표 추가 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| Figure 1과 Figure 2 삽입 및 가독성 확인 | 완료 | `산출물/도식/figure1_overall_architecture.png`, `산출물/도식/figure2_g4_reranking.png` |
| Discussion과 Limitations 보완 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| 교육 효과와 검색 성능 주장의 범위 구분 | 완료 | `19_paper_draft.md`, `19_paper_draft_english.md` |
| 응답 품질 평가를 검색 성능과 분리된 보조 분석으로 정리 | 완료 | `22_response_quality_eval_results.md`, `19_paper_draft_english.md` |
| 참고문헌 30편 구성 및 본문 인용 연결 | 완료 | `20_reference_candidates.md`, `19_paper_draft.md`, `19_paper_draft_english.md` |
| 공식 IEEE Access 템플릿 기반 영문 통합 원고 생성 | 완료 | `논문/IEEE Access 영문 통합 원고.docx` |
| DOCX와 동일한 제출 검토용 PDF 생성 | 완료 | `논문/IEEE Access 영문 통합 원고.pdf` |
| 통합 원고 전 페이지 렌더링 검수 | 완료 | 12페이지, 표·그림·한글·번호 체계 이상 없음 |

## 제출 전 저자 확인 항목

| 우선순위 | 항목 | 현재 상태 |
|---:|---|---|
| 1 | 저자명, 소속, 주소, 교신저자 정보 입력 | 미입력 |
| 2 | 저자 ORCID, 약력, 사진 입력 여부 결정 | 미입력 |
| 3 | 연구비와 이해상충 정보 확인 | 확인 필요 |
| 4 | AI 보조 사용 공개 문구의 범위와 최종 표현 확인 | 확인 필요 |
| 5 | 참고문헌의 저자명·권호·페이지·DOI 최종 교정 | 30편 초안 완료, 제출 전 교정 필요 |
| 6 | 대표 개선·실패 사례에 실제 매뉴얼 이미지를 추가할지 결정 | 선택 사항 |
| 7 | 교수 검토 후 제목, 초록, 핵심 기여 문장 확정 | 검토 필요 |
| 8 | IEEE Access 제출 시스템의 최종 파일·메타데이터 입력 | 제출 단계에서 수행 |

## 연구의 한계로 유지할 항목

다음 항목은 현재 연구에서 완료된 실험으로 표현하지 않는다.

- 단일 협동 로봇 매뉴얼과 내부 70개 질의셋을 이용한 평가이다.
- 가중치 선택과 최종 평가는 동일한 내부 질의셋을 기반으로 한다.
- 독립 외부 질의셋과 다른 로봇 매뉴얼을 이용한 일반화 검증은 수행하지 않았다.
- 8GB RAM급 제한 환경은 설계 목표이며, 해당 장비에서 실행 시간과 최대 메모리 사용량을 실측하지 않았다.
- 실제 교육생의 학습 효과, 수행 시간, 오류율, 만족도는 검증하지 않았다.
- 응답 품질은 모든 모델에서 일관되게 개선되지 않았으므로 핵심 기여는 검색 후보 순위 개선으로 제한한다.

## 원고에서 조심해야 할 표현

| 피해야 할 표현 | 대체 표현 |
|---|---|
| 교육 효과를 검증하였다 | 검색 성능을 평가하고 교육적 활용 가능성을 검토하였다 |
| G4가 응답 품질을 개선하였다 | G4는 검색 후보 순위를 개선했으며 응답 품질은 별도 보조 분석으로 평가하였다 |
| 이미지 검색 문제가 해결되었다 | 이미지 검색 순위가 개선되었으나 Image Recall@1은 48.6%로 한계가 남아 있다 |
| 8GB RAM 환경에서 성능을 검증하였다 | 8GB RAM급 로컬 실행을 설계 목표로 했으나 실제 메모리와 실행 시간은 실측하지 않았다 |
| CLIP을 사용하였다 | CLIP은 관련 연구로 설명하고 실제 의미 유사도 신호에는 SigLIP을 사용하였다 |

## 현재 제출 후보 파일

1. `논문/IEEE Access 영문 통합 원고.docx`
2. `논문/IEEE Access 영문 통합 원고.pdf`
3. `논문/원문 초안.docx`
4. `논문/영문 초안.docx`
