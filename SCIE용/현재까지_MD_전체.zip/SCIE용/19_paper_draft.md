﻿# 논문 초안 v1.1

> 본 문서는 SCIE/IEEE Access 투고용 영문 원고 작성에 앞서 정리한 국문 학술 초안이다.
> 검색 성능, 응답 품질 평가 및 오프라인·제한 자원 실행 목표를 반영하였다.

## 제목 후보

**A Context-Aware Multimodal Retrieval-Augmented Generation Framework for Collaborative Robot Training**

대안 제목:

**Improving Multimodal Retrieval for Collaborative Robot Training Using Context-Aware Retrieval-Augmented Generation**

## 초록

협동 로봇 실습에서는 절차 설명, 설정값, 안전 조건, 이미지 및 도식 등 서로 다른 형태의 정보를 함께 해석해야 한다. 그러나 텍스트 기반 검색과 텍스트 중심의 검색 증강 생성(Retrieval-Augmented Generation, RAG)은 실습 화면, 배선도 및 설정 화면과 같은 시각 자료를 직접 활용하거나 현재 실습 단계와 관련된 근거를 우선적으로 제시하는 데 한계가 있다. 본 연구는 이러한 한계를 완화하기 위해 협동 로봇 실습을 위한 상황 인지형 멀티모달 RAG 프레임워크를 제안한다. 제안 프레임워크는 협동 로봇 매뉴얼에서 추출한 텍스트 청크와 이미지·도식을 각각 인덱싱한다. 전처리 단계에서는 경계 상자(bounding box, BBox) 거리를 공간 후보 필터로 적용하고, 필터를 통과한 텍스트-이미지 쌍을 SigLIP 의미 유사도에 따라 순위화하여 매핑 메타데이터를 생성한다. 이 매핑 정보는 텍스트 검색, 이미지 전용 검색 및 페이지 근접도와 결합된다. 또한 질의로부터 실습 단계를 추정하고, 단계별 페이지 범위, 절 제목 및 핵심어로 구성된 문맥 맵(context map)을 이용하여 검색 후보를 재순위화한다. 시스템은 로컬 벡터 데이터베이스와 4-bit 양자화 대규모 언어 모델을 사용함으로써 외부 API에 대한 의존을 줄이고, 오프라인 및 8GB RAM급 제한 자원 환경에서의 실행 가능성을 고려하였다. 다만 8GB RAM급 환경은 설계 목표이며, 해당 환경에서의 실행 시간과 메모리 사용량은 본 연구에서 실측하지 않았다.

평가를 위해 협동 로봇 실습 매뉴얼을 기반으로 70개 질의를 구성하고, 각 질의에 정답 텍스트, 정답 이미지 및 실습 단계 라벨을 부여하였다. 키워드 기반 검색(G1), 텍스트 기반 RAG(G2), 멀티모달 RAG(G3), 단계 추정 기반 상황 인지형 멀티모달 RAG(G4)를 비교한 결과, G4의 Image Recall@5는 G3의 71.4%에서 77.1%로, Image Recall@10은 80.0%에서 87.1%로 증가하였다. Image MRR은 0.572에서 0.620으로, Image Recall@1은 45.7%에서 48.6%로 상승하였다. 이 결과는 단계 문맥을 반영한 재순위화가 관련 이미지와 도식의 후보 순위를 개선할 가능성을 보여준다. 그러나 G4의 Image Recall@1은 50% 미만이었으며, 생성 응답 품질도 모든 모델에서 일관되게 향상되지 않았다. 따라서 본 연구의 기여는 생성 품질의 향상보다 상황 인지형 멀티모달 검색의 후보 순위 개선에 초점을 둔다. 또한 질의 기반 단계 추정 오류와 동일 페이지 또는 동일 절에 유사 이미지가 다수 존재하는 경우에는 정답 이미지를 세밀하게 구분하기 어려웠다.

## 키워드

Collaborative robot training, multimodal RAG, retrieval-augmented generation, context-aware retrieval, engineering education, robot manual retrieval

## 1. 서론

협동 로봇은 제조, 교육 및 연구 환경에서 인간과 작업 공간을 공유하는 로봇으로 활용되고 있다. 선행 연구에서는 협동 로봇의 개념, 안전, 조작 및 프로그래밍을 결합한 실습형 교육과정의 필요성이 제시되었다[1]. 또한 협동 작업에는 안전하고 직관적인 인간-로봇 상호작용이 요구되므로[2], [3], 학습자는 절차 지식과 기술 매뉴얼의 시각적 근거를 함께 이해할 필요가 있다.

본 연구에서 분석한 협동 로봇 실습 매뉴얼은 절차 설명, 티치 펜던트 화면, 배선도 및 안전 설정 이미지가 여러 페이지에 분산된 형태로 구성되어 있다[30]. 특정 실습 상황에 필요한 정보를 확인하려면 메뉴명과 설정 항목뿐 아니라 화면 위치와 관련 이미지까지 함께 탐색해야 한다. 특히 초보 학습자는 현재 수행 중인 실습 단계와 매뉴얼의 해당 절을 연결하는 과정에서 어려움을 겪을 수 있다.

검색 증강 생성(Retrieval-Augmented Generation, RAG)은 외부 문서에서 검색한 근거를 언어 모델의 응답 생성에 활용하는 방법이다[4]. 일반적인 텍스트 기반 RAG는 텍스트 청크 검색을 중심으로 구성되므로, 이미지, 도식 및 화면 예시가 절차 이해에 필요한 문서에서는 제공 가능한 근거의 범위가 제한될 수 있다. 특히 협동 로봇 실습 매뉴얼에서는 텍스트와 시각 자료가 상호 보완적으로 사용되므로, 텍스트 검색만으로는 관련 근거를 충분히 구성하기 어렵다.

이에 본 연구는 협동 로봇 실습을 위한 상황 인지형 멀티모달 RAG 프레임워크를 제안한다. 제안 프레임워크는 매뉴얼의 텍스트와 이미지·도식을 함께 검색하고, 질의로부터 추정한 실습 단계 문맥을 이용하여 검색 결과를 재순위화한다. 연구의 주요 목적은 최종 응답 생성 성능 자체를 높이는 데 있지 않으며, 응답 생성에 앞서 관련 텍스트 근거와 이미지·도식을 보다 높은 순위에 배치하는 데 있다.

본 연구의 주요 기여는 다음과 같다.

1. 협동 로봇 실습 매뉴얼을 대상으로 텍스트, 이미지/도식, 실습 단계 라벨을 포함한 70개 평가 질의셋을 구축하였다.
2. 키워드 검색, 텍스트 기반 RAG, 멀티모달 RAG, 상황 인지형 멀티모달 RAG를 동일 질의셋에서 비교할 수 있는 실험 구조를 설계하였다.
3. BBox 기반 공간 후보 필터와 SigLIP 기반 의미 유사도 순위화를 분리한 텍스트-이미지 매핑을 구성하고, 이를 텍스트 검색, 이미지 전용 검색 및 페이지 근접도와 결합하였다.
4. 질의 기반 실습 단계 추정과 단계별 문맥 맵을 이용한 재순위화를 적용하여 이미지·도식의 검색 순위와 Both@k 성능을 비교하였다.
5. 생성 응답 품질을 별도 평가 항목으로 분석하고, 개선 사례와 실패 사례를 통해 제안 방식의 효과와 한계를 검토하였다.

## 2. 관련 연구

### 2.1 Retrieval-Augmented Generation

RAG는 대규모 언어 모델의 파라미터에 내재된 지식만으로 응답을 생성하는 한계를 보완하기 위해 외부 문서에서 검색한 근거를 함께 활용하는 방법이다[4]. 이후 연구에서는 다수의 검색 문서를 생성 모델에서 결합하는 구조[5]와 대규모 외부 메모리를 언어 모델 학습에 활용하는 구조[6]가 제안되었다. 일반적인 RAG 시스템은 문서를 청크 단위로 분할하여 임베딩하고, 질의와 관련된 근거를 검색한 뒤 이를 언어 모델의 문맥으로 제공한다. 이에 따라 RAG 연구에서는 검색, 증강, 생성 및 평가를 서로 연관되지만 구분 가능한 구성요소로 다룬다[11].

RAG의 검색 단계는 희소 검색(sparse retrieval)과 밀집 검색(dense retrieval)으로 구분할 수 있다. BM25는 키워드 기반 희소 검색의 대표적인 기준선으로 사용되며[8], Dense Passage Retrieval(DPR)은 질의와 문서를 밀집 표현으로 변환하여 검색하는 방법을 제시하였다[7]. Sentence-BERT는 문장 임베딩을 이용한 효율적인 의미 유사도 검색 가능성을 제시하였다[9]. 본 연구의 G1은 키워드 기반 기준선에 해당하고, G2는 BGE-M3 임베딩을 이용한 다국어 밀집 검색 기반 RAG에 해당한다[10].

RAG는 기술 매뉴얼, 사내 문서 및 교육 자료와 같이 문서에 도메인 지식이 명시된 환경에 적용될 수 있다. 그러나 텍스트 기반 RAG는 주로 문장 또는 문단 단위의 검색에 의존하므로, 이미지, 도식, 표 및 화면 캡처가 중요한 문서에서는 시각적 근거를 직접 활용하기 어렵다. 본 연구에서 사용하는 협동 로봇 실습 매뉴얼도 텍스트와 시각 자료를 함께 포함한다.

### 2.2 Multimodal Retrieval

멀티모달 검색은 텍스트, 이미지, 도식 및 오디오와 같은 서로 다른 양식(modality)의 정보를 함께 활용하여 관련 자료를 검색하는 방법이다. 이미지와 텍스트를 공유 임베딩 공간에 매핑하는 비전-언어 모델을 이용하면 텍스트 질의에 대한 이미지 검색과 이미지-텍스트 연결이 가능하다. CLIP은 대조 학습 기반 이미지-텍스트 표현을 제시하였고[12], ALIGN은 대규모의 잡음이 포함된 이미지-텍스트 쌍을 이용한 이중 인코더 학습을 제안하였다[13]. BLIP은 비전-언어 사전학습을 이해와 생성 과제로 확장하였다[14]. SigLIP은 이미지-텍스트 사전학습에서 전역 softmax 정규화 대신 쌍별 sigmoid 손실을 적용한다[15]. 본 연구에서는 CLIP, ALIGN 및 BLIP을 관련 비전-언어 연구로 다루고, 실제 텍스트-이미지 의미 유사도 계산에는 SigLIP을 사용하였다.

멀티모달 RAG 연구는 외부 메모리의 텍스트와 이미지를 함께 활용하는 방향으로 확장되었다. MuRAG는 멀티모달 메모리에서 근거를 검색하여 질의응답에 활용하였고[16], REVEAL은 여러 종류의 멀티모달 지식원을 통합하였다[17]. RA-CM3는 텍스트와 이미지를 모두 검색하고 생성하는 구조를 제안하였다[18]. 이러한 연구는 멀티모달 외부 근거의 활용 가능성을 제시하지만, 소규모 기술 실습 매뉴얼의 단계 문맥 기반 검색을 직접 다루지는 않는다.

본 연구에서 사용한 실습 매뉴얼에서는 하나의 절차가 텍스트 설명과 이미지 자료로 함께 제시된다. 예를 들어 메뉴 경로는 텍스트로 설명되지만, 해당 조작을 확인하려면 티치 펜던트 또는 설정 화면 이미지가 필요할 수 있다. 문서 이해 연구에서도 텍스트 내용과 2차원 배치 정보가 상호 보완적임이 제시되었다[19]. 따라서 본 연구 환경에서는 텍스트와 이미지 검색 결과를 독립적으로 제공하는 것만으로 충분하지 않으며, 두 자료가 연결되는 페이지 배치와 실습 단계 문맥을 함께 고려할 필요가 있다.

### 2.3 Context-Aware Retrieval for Training Guidance

실습 환경의 질의는 특정 작업 단계와 연관될 수 있다. 동일하거나 유사한 용어를 포함한 질의라도 설치, 안전 설정 및 프로그램 실행 등 단계에 따라 필요한 근거와 관련 이미지가 달라질 수 있다. 협동 로봇 교육 연구에서는 이론 설명뿐 아니라 실험실 실습, 안전, 조작 및 프로그래밍 모듈의 중요성이 논의되어 왔다[1]. 산업용 인간-로봇 협업 연구와 ISO 안전 지침도 안전하고 이해 가능한 조작의 중요성을 제시한다[2], [3]. 이러한 특성을 고려할 때, 실습 안내를 위한 검색에서는 질의의 의미 유사도와 함께 실습 단계 및 매뉴얼 구조를 반영할 필요가 있다.

본 연구에서는 질의로부터 실습 단계를 추정하고, 단계별 페이지 범위, 절 제목 및 핵심어로 구성된 문맥 맵을 멀티모달 검색 결과의 재순위화에 활용한다.

## 3. 제안 프레임워크

### 3.1 전체 구조

제안 프레임워크는 협동 로봇 실습 매뉴얼에서 텍스트와 이미지·도식을 추출하고, 각 자료를 검색 가능한 형태로 전처리하여 인덱싱한다. 실습 관련 질의가 입력되면 관련 텍스트 청크와 이미지 후보를 검색하고, 선택된 로컬 대규모 언어 모델(LLM)을 이용하여 응답을 생성한다.

전체 파이프라인은 다음과 같다.

1. 매뉴얼 PDF에서 텍스트와 이미지·도식을 추출한다.
2. 텍스트를 청크 단위로 분할하고 페이지, 절, 주변 문맥 및 텍스트 BBox를 저장한다.
3. 추출한 이미지에는 페이지 정보와 이미지 BBox를 저장한다.
4. 동일 페이지와 다음 페이지의 텍스트-이미지 쌍을 수집한 후, BBox 거리로 공간 후보를 제한하고 SigLIP 의미 유사도에 따라 후보를 순위화하여 매핑 정보를 생성한다.
5. 텍스트 임베딩, 이미지 인덱스 및 텍스트-이미지 매핑 메타데이터를 로컬 벡터 데이터베이스에 저장한다.
6. 사용자 질의에 대해 텍스트 후보와 이미지 후보를 검색한다.
7. G3에서는 텍스트 검색, 이미지 검색, 페이지 근접도 및 사전 계산된 SigLIP 기반 텍스트-이미지 매핑 점수를 결합한다.
8. G4에서는 질의로부터 실습 단계를 추정하고, 해당 단계의 문맥 맵을 반영하여 후보를 재순위화한다.
9. 검색된 근거를 바탕으로 로컬 LLM이 실습 안내 답변을 생성한다.

### 3.2 텍스트 전처리와 인덱싱

매뉴얼에서 추출한 텍스트는 실습 절차와 의미 단위가 유지되도록 청크로 분할하였다. 각 청크에는 원문 텍스트, 페이지 번호, 절 관련 정보 및 해당 텍스트 영역의 BBox 좌표를 저장하였다. BBox는 PDF 페이지에서 텍스트가 차지하는 직사각형 영역을 `(x0, y0, x1, y1)`로 나타낸다. 다국어 텍스트 임베딩에는 BGE-M3를 사용하였고[10], 임베딩·문서·메타데이터의 영구 저장에는 ChromaDB를 사용하였다[28].

텍스트 기반 RAG인 G2는 질의 임베딩과 텍스트 청크 임베딩 간 유사도를 기준으로 상위 k개의 텍스트 후보를 검색한다. 고정된 소규모 코퍼스에서 순위의 재현성을 확보하기 위해, 구현에서는 저장된 벡터를 불러온 뒤 질의와 모든 텍스트 벡터의 제곱 유클리드 거리를 계산하여 정렬한다. G3와 G4의 이미지 벡터에도 동일한 전수 순위화 절차를 적용한다. 따라서 ChromaDB는 영구 벡터 저장소로 사용되고, 최종 실험 순위는 근사 최근접 이웃 탐색을 거치지 않는다. 검색된 텍스트 후보는 LLM 응답 생성의 근거로 사용된다.

### 3.3 이미지/도식 전처리와 검색

매뉴얼에서 추출한 이미지·도식은 파일명, 페이지 번호 및 이미지 BBox를 기준으로 관리하였다. 이미지 자료는 주변 설명과 분리될 경우 의미를 특정하기 어려울 수 있으므로, 전처리 단계에서 텍스트 청크와 이미지 간 공간적·의미적 연관성을 계산하였다. 공간 메타데이터의 활용은 문서 배치가 텍스트 외의 정보를 제공한다는 선행 연구의 관찰과도 관련된다[19]. 각 텍스트 청크에 대해 동일 페이지와 다음 페이지의 이미지를 초기 후보로 수집하였다. 동일 페이지에서는 텍스트 BBox 집합과 이미지 BBox 중심점 사이의 2차원 거리를 계산하고, 대상 매뉴얼에서 이미지가 관련 텍스트 아래에 배치되는 경향을 반영하여 거리를 보정하였다. 다음 페이지의 후보에는 공간 패널티를 적용하였다.

BBox 거리는 최종 매핑 점수에 직접 포함하지 않고 후보 게이트로만 사용하였다. 보정 거리가 300포인트 미만인 이미지는 공간 후보로 유지하였다. 한편 공간적으로 멀지만 의미적으로 관련된 이미지가 제외되는 것을 줄이기 위해, 강건 정규화(robust normalization)를 적용한 SigLIP 유사도가 0.40 이상인 후보는 유지하였다. 후보 순위와 `mapping_score`는 SigLIP 이미지-텍스트 코사인 유사도로 결정하였다[15]. 코사인 유사도는 전처리 쌍 분포의 강건 구간을 이용하여 0과 1 사이로 정규화하였으며, 전체 데이터에 동일한 고정 경계를 적용하였다. 따라서 BBox는 공간적으로 먼 이미지를 제외하는 역할을 하고, SigLIP은 유지된 후보를 의미 유사도에 따라 순위화한다. 이 계산은 오프라인 전처리에서 한 번 수행되며, 실행 단계에서는 저장된 매핑 정보만 사용한다.

G3의 이미지 후보 점수는 다음 검색 신호를 결합하여 계산하였다.

- 이미지 전용 검색 점수
- 텍스트 검색 결과와 이미지 페이지 간 근접도
- BBox 후보 필터를 거쳐 사전 계산된 SigLIP 텍스트-이미지 매핑 점수
- 기본 후보 순위 점수

이와 같은 결합을 통해 질의와 관련된 텍스트 근거뿐 아니라 해당 근거와 공간적·의미적으로 연결된 이미지와 도식을 검색한다. 그림 1은 BBox 및 SigLIP 기반 매핑을 포함한 전체 시스템 구조를 나타내며, 그림 2는 G3 후보에 자동 추정된 단계 문맥을 적용하는 G4의 후보 확장 및 재순위화 과정을 나타낸다.

### 3.4 상황 인지형 재순위화

G4는 G3에 실습 단계 추정과 문맥 맵 기반 재순위화를 추가한 구조이다. 문맥 맵은 각 실습 단계와 관련된 페이지 범위, 절 제목, 핵심어 및 매핑 근거로 구성하였다. 평가 정보의 누수를 방지하기 위해 정답 이미지 파일명과 정답 청크 식별자는 문맥 맵에 포함하지 않았다. 문맥 맵은 매뉴얼의 절 구조와 각 실습 단계의 의미를 기준으로 수동 검토하여 구축하였다.

G4의 재순위화 절차는 다음과 같다.

1. 질의와 실습 단계 문맥 프로파일 간 BGE-M3 의미 유사도를 비교하여 실습 단계를 추정한다.
2. 최고 단계 유사도가 0.45 미만이거나 1위와 2위 단계 후보 간 유사도 차이가 0.03 미만이면 G4를 적용하지 않고 G3 순위를 유지한다.
3. 추정된 실습 단계와 연결된 페이지 범위와 핵심어를 불러온다.
4. 검색 후보가 관련 페이지 범위에 포함되면 추가 점수를 부여한다.
5. 후보의 주변 텍스트 또는 절 정보가 단계별 핵심어와 일치하면 점수를 보정한다.
6. 기존 G3 점수와 단계 문맥 점수를 결합하여 최종 순위를 계산한다.

이 절차는 정답 라벨을 이용하여 검색 후보를 직접 선택하지 않고, 매뉴얼 구조와 추정된 실습 단계 정보를 이용하여 후보의 우선순위를 조정한다. 따라서 G4는 단계 문맥을 검색 과정에 반영하는 상황 인지형 재순위화 구조로 정의하였다.

**Algorithm 1. G4의 상황 인지형 멀티모달 재순위화**

```text
Input: 질의 q; G3 텍스트 후보 T; G3 이미지 후보 I;
       단계 프로파일 S; 단계 문맥 맵 C; 텍스트/이미지 반환 수 k_T, k_I
Output: 재순위화된 텍스트 후보 T'와 이미지 후보 I'
Parameters: tau_s=0.45, tau_m=0.03, beta_t=0.28,
            lambda_c=0.50, lambda_p=0.25, R=120

1:  e_q <- BGE-M3(q)
2:  각 단계 s in S에 대해 a_s <- cos(e_q, e_s)를 계산한다.
3:  s* <- argmax_s(a_s)로 두고, 상위 두 유사도를 a_1 >= a_2로 둔다.
4:  if a_1 < tau_s or (a_1-a_2) < tau_m then
5:      return G3-TopK(T,k_T), G3-TopK(I,k_I)
6:  c* <- C[s*]에서 텍스트/이미지 페이지 범위, 핵심어, 절 용어,
        단계 가중치 w_s를 불러오고, 단계 이미지 범위의 유효 후보를 I에 추가한다.
7:  for each text candidate t in T do
8:      (p_t,k_t,h_t) <- StageMatch(t,c*)
9:      c_t <- w_s(0.55p_t + 0.30k_t + 0.15h_t)
10:     b_t <- 1-(r_G3(t)-1)/|T|;  f_t <- b_t + beta_t c_t
11: for each image candidate i in I do
12:     b_i <- 0.25v_i + 0.15l_i + 0.50n_i + 0.05m_i + 0.05d_i
13:     (p_i,k_i,h_i) <- StageMatch(i,c*)
14:     c_i <- w_s(0.50p_i + 0.10k_i + 0.40h_i)
15: 모든 이미지 후보를 b_i로 정렬하여 기본 순위 r_B(i)를 계산한다.
16: for each image candidate i in I do
17:     if r_B(i) <= R: rho_i <- 1-(r_B(i)-1)/R
18:     else if p_i > 0: rho_i <- 0.35; else: rho_i <- 0
19:     f_i <- b_i + lambda_c c_i rho_i + lambda_p p_i
20: T를 f_t, I를 f_i의 내림차순으로 정렬한다.
21: return TopK(T,k_T), TopK(I,k_I)
```

Algorithm 1에서 `T`는 G4 적용 시 최대 30개까지 확장한 G3 텍스트 후보이고, `I`는 텍스트-이미지 연결 후보, 인접 페이지 후보, 이미지 인덱스 후보 및 추정 단계의 이미지 페이지 범위 후보를 합친 집합이다. `S`는 단계명, 절 용어, 본문·동작 핵심어 및 매뉴얼 근거로 구성된 단계 프로파일 집합이며, `C`는 각 단계의 텍스트·이미지 페이지 범위와 용어 정보를 저장한 문맥 맵이다. `a_1`과 `a_2`는 질의와 단계 프로파일 간 코사인 유사도의 1위와 2위 값이다.

`p_x`, `k_x`, `h_x`는 각각 후보 `x`의 단계 페이지 일치도, 핵심어 일치도 및 절 제목 일치도를 나타낸다. 페이지 일치도는 단계 범위 안에서 1.0, 범위에서 한 페이지 떨어지면 0.70, 두 페이지 떨어지면 0.45, 그 밖에는 0으로 계산한다. 핵심어와 절 제목 일치도는 후보 메타데이터에서 일치한 용어 수를 이용하여 0과 1 사이로 정규화한다. 이미지 기본 점수의 `v_i`, `l_i`, `n_i`, `m_i`, `d_i`는 각각 이미지 전용 검색 점수, 연결된 텍스트 순위 점수, 페이지 근접도, BBox 후보 필터 이후 저장된 SigLIP 매핑 점수 및 도식 신뢰도를 의미한다. `b_x`, `c_x`, `f_x`는 각각 기본 점수, 단계 문맥 점수 및 최종 점수이며, `rho_i`는 기본 순위가 낮은 이미지에 문맥 점수가 과도하게 적용되지 않도록 하는 순위 감쇠 계수이다.

단계 최고 유사도 `a_1`이 `tau_s`보다 낮거나 상위 두 단계의 차이가 `tau_m`보다 작으면 단계 추정의 신뢰도가 충분하지 않은 것으로 판단하고 G3 결과로 복귀한다. Algorithm 1의 임계값과 가중치는 모든 질의에 동일하게 적용되며, 선택 절차는 4.4절에 기술한다. 문맥 맵 `C`에는 질문 번호, 정답 이미지 파일명 및 정답 청크 식별자를 포함하지 않아 평가 정답이 재순위화 입력으로 사용되지 않도록 하였다.

### 3.5 로컬 LLM 기반 응답 생성과 제한 자원 설계

제안 시스템은 제한 자원 환경을 고려하여 로컬 LLM 기반 응답 생성 구조로 설계하였다. Qwen 2.5[22], Gemma 2[23] 및 Llama 3.1 계열[24] 모델을 동일한 검색 조건에서 비교할 수 있도록 구성하였으며, 검색된 텍스트 근거와 이미지 후보 정보를 문맥으로 제공하여 실습 안내 응답을 생성하였다.

오프라인 실행을 위해 외부 LLM API를 호출하지 않고 Ollama 기반 로컬 모델을 사용하였다. 모델은 7B~9B급 Q4 양자화 모델로 구성하였으며, 이는 모델 메모리와 추론 요구량을 낮추기 위한 저비트 양자화 연구의 일반적 방향과 관련된다[25], [26], [27]. 다만 이 인용은 양자화 배경을 설명하기 위한 것이며, 본 시스템은 QLoRA, GPTQ 또는 AWQ를 새로운 기여로 구현한 것이 아니라 로컬 런타임에서 제공되는 Q4 모델 패키지를 사용한다. BBox 거리와 SigLIP 기반 텍스트-이미지 유사도는 전처리 단계에서 계산하고, 실행 단계에서는 저장된 인덱스와 매핑 정보를 사용하도록 설계하였다. 이러한 구성은 클라우드 기반 모델 없이도 텍스트 근거와 관련 이미지를 함께 제공하는 것을 목표로 한다.

다만 본 연구의 정량 평가는 G1~G4의 검색 성능 비교에 초점을 두며, 오프라인 실행 속도와 8GB RAM 환경의 시스템 성능은 측정하지 않았다. 따라서 제한 자원 관련 내용은 검증된 최소 사양이 아니라 시스템의 설계 목표로 해석해야 한다.

응답 품질은 검색 성능과 구분된 평가 항목으로 분석하였다. 전체 응답에는 정확성, 구체성, 실습 단계 적합성, 안전성 및 이해 용이성을 기준으로 한 규칙 기반 루브릭 평가를 적용하였다. 구체적인 평가 기준과 절차는 6절에 제시한다.

## 4. 실험 설계

### 4.1 데이터셋

실험 데이터는 두산로보틱스 협동 로봇 실습 매뉴얼을 기반으로 구성하였다[30]. 총 70개의 평가 질의를 작성하고, 각 질의에 정답 텍스트, 정답 이미지 및 실습 단계 라벨을 부여하였다. 질의 범주는 설치, 전원, 티치 펜던트 조작, 직접 교시, 좌표 설정, 안전 설정, I/O 배선 및 시스템 관리를 포함한다.

질의셋은 정답 이미지를 명확하게 특정할 수 있는 질의를 중심으로 구성하였다. 이는 이미지 검색 성능을 파일 단위로 정량 평가하기 위한 설계이다.

### 4.2 비교군

비교군은 다음 네 가지로 구성하였다.

| 비교군 | 이름 | 설명 |
|---|---|---|
| G1 | Keyword Search | 질의와 텍스트 청크 간 핵심어 일치도를 기반으로 검색 |
| G2 | Text-only RAG | BGE-M3 텍스트 임베딩을 이용한 텍스트 청크 검색 |
| G3 | Multimodal RAG | 텍스트 검색, 이미지 검색, 페이지 근접도 및 BBox 필터 기반 SigLIP 텍스트-이미지 매핑 결합 |
| G4 | Context-aware Multimodal RAG | 질의로부터 실습 단계를 추정하고 G3 후보에 문맥 맵 기반 재순위화 적용 |

G1과 G2는 텍스트 검색 성능을 비교하기 위한 기준선이다. G3는 G2의 텍스트 검색 결과에 이미지·도식 검색 신호를 결합한 멀티모달 구조이며, G4는 추정된 실습 단계 정보를 이용하여 G3의 후보를 재순위화한 제안 방식이다.

### 4.3 평가 지표

검색 성능은 Recall@k와 평균 역순위(Mean Reciprocal Rank, MRR)를 이용하여 평가하였다. MRR은 각 질의에서 최초 정답의 순위 역수를 계산한 뒤 전체 질의에 대해 평균하며, 기존 순위 기반 질의응답 평가 방식에 근거한다[29].

Text Recall@k는 상위 k개의 텍스트 후보에 정답 텍스트 또는 동등한 관련 정보가 포함된 질의의 비율이다. Image Recall@k는 상위 k개의 이미지 후보에 정답 이미지가 포함된 질의의 비율이다. MRR은 최초 정답 후보의 순위를 역수로 변환한 후 전체 질의에 대해 평균한 값이다. Both@k는 상위 k개 결과에서 정답 텍스트와 정답 이미지가 모두 검색된 질의의 비율로 정의하였다.

텍스트 검색에는 완화된 관련성 기준(relaxed relevance criterion)을 적용하였다. 검색된 텍스트가 정답 문장과 완전히 일치하지 않더라도 동일 페이지 또는 절에 속하거나, 기준 답변의 핵심어를 포함하거나, 의미상 동일한 절차·설정 정보를 포함하면 정답으로 판정하였다. 이 기준은 대상 매뉴얼의 절차 정보가 인접 청크 또는 동일 페이지의 여러 문장에 분산된 특성을 반영한다.

이미지 검색에는 엄격한 파일명 일치(strict filename matching) 기준을 적용하였다. 정답 이미지의 파일명이 상위 k개 후보에 포함된 경우에만 정답으로 판정하였으며, 동일 페이지의 유사 이미지라도 파일명이 다르면 오답으로 처리하였다. 따라서 Text Recall@k와 Text MRR은 완화된 기준의 텍스트 검색 성능을, Image Recall@k와 Image MRR은 엄격한 기준의 이미지 검색 성능을 나타낸다. Both@k는 완화된 텍스트 정답과 엄격한 이미지 정답이 동시에 충족된 비율이다. 두 양식에 서로 다른 판정 기준을 적용했으므로 텍스트 지표와 이미지 지표의 절대값을 직접 비교할 때에는 주의가 필요하다.

| 지표 | 평가 기준 |
|---|---|
| Text Recall@k / Text MRR | 완화 기준: 페이지·절 일치, 핵심어 포함 또는 의미적 동등성 중 하나를 충족하면 정답 |
| Image Recall@k / Image MRR | 엄격 기준: 정답 이미지 파일명이 상위 k개 후보에 포함되어야 정답 |
| Both@k | 완화된 텍스트 정답과 엄격한 이미지 정답을 모두 충족해야 정답 |

### 4.4 검색 점수 구성과 가중치 선택

G3 이미지 후보의 기본 점수는 이미지 전용 검색 점수 0.25, 텍스트 후보 순위 점수 0.15, 검색 텍스트와 이미지 간 페이지 근접도 0.50, 사전 계산된 SigLIP 매핑 점수 0.05 및 도식 신뢰도 0.05를 가중합하여 계산하였다. BBox 거리는 점수식에 포함하지 않고 전처리 후보 필터로만 사용하였다. G4의 이미지 문맥 점수는 페이지 0.50, 핵심어 0.10 및 절 0.40의 가중합으로 구성하였다. 최종 이미지 점수에는 문맥 점수에 0.50의 가중치를 적용하고 단계-페이지 사전 점수에 0.25의 가중치를 적용하였다. 문맥 점수에는 G3 기본 순위가 낮아질수록 감소하는 순위 계수를 함께 적용하였다. 기본 순위 120위 밖에 있으나 추정 단계의 페이지 범위에 포함된 후보에는 순위 계수 0.35를 적용하였다. 텍스트 재순위화에서는 기존 검색 순위 점수에 단계 문맥 점수의 0.28배를 더하였다.

Algorithm 1의 기호로 나타내면 단계 적용 최소 유사도 `tau_s`는 0.45, 상위 단계 간 최소 차이 `tau_m`은 0.03, 텍스트 문맥 계수 `beta_t`는 0.28, 이미지 문맥 계수 `lambda_c`는 0.50, 단계 페이지 사전 계수 `lambda_p`는 0.25, 기본 순위 감쇠 구간 `R`은 120으로 설정하였다. 이 값들은 특정 질의마다 달라지는 값이 아니라 전체 평가에 고정하여 적용한 구현 파라미터이다.

가중치 후보는 70개 질의에서 생성한 후보별 특징 캐시를 이용한 제한적 격자 탐색으로 비교하였다. 엄격한 기준의 Image MRR을 우선 선택 지표로 사용하고, Recall@5와 Recall@10을 보조 지표로 적용하였다. 또한 5-fold 교차검증을 수행하여 fold별 안정성을 확인하였다. 비교 결과, BBox 근접도를 매핑 점수에 직접 가산하는 구성보다 BBox를 후보 필터로만 사용하고 SigLIP으로 매핑 순위를 결정하는 구성이 더 높은 평균 성능을 보였다. 다만 가중치 탐색과 최종 평가는 동일한 70개 질의를 사용한 내부 파일럿 결과이다. 따라서 이 결과는 독립적인 외부 테스트셋에 대한 일반화 성능을 입증하지 않으며, 별도의 홀드아웃 데이터 또는 추가 매뉴얼을 이용한 검증이 필요하다.

다른 G3 검색 구성은 고정하고 텍스트-이미지 매핑 방식만 비교한 결과는 다음과 같다. 이 비교는 BBox와 SigLIP 자체를 독립적으로 평가하기 위한 것이 아니라, 두 요소의 역할을 분리한 설계 근거를 확인하기 위한 보조 분석이다.

| 텍스트-이미지 매핑 구성 | Image R@1 | Image R@5 | Image R@10 | Image MRR |
|---|---:|---:|---:|---:|
| BBox 기반 매핑 점수 | 37.1% | 68.6% | 80.0% | 0.518 |
| BBox 후보 필터 + SigLIP 순위화(최종) | 45.7% | 71.4% | 80.0% | 0.572 |

### 4.5 실험 환경

실험은 로컬 노트북에서 수행하였다. 제한 자원 환경에서의 오프라인 실행은 시스템 설계 목표이지만, 본 연구의 정량 실험은 아래의 개발·평가 환경에서 수행하였다. 따라서 8GB RAM급 환경은 모델 선택과 시스템 설계의 목표로만 제시하며, 해당 장비에서의 실행 시간, 메모리 사용량 및 동시 실행 안정성은 검증되지 않았다. 본 연구의 검색 성능 및 응답 품질 결과는 동일한 개발 환경에서 비교군 간 차이를 측정한 값이다.

| 항목 | 내용 |
|---|---|
| 운영체제 | Windows |
| 장비 | HP OMEN Gaming Laptop 16-am0xxx |
| CPU | Intel Core Ultra 7 255H, 16 cores / 16 logical processors |
| RAM | 약 24GB |
| GPU | NVIDIA GeForce RTX 5060 Laptop GPU, Intel Graphics |
| Python | 3.12.10 (.venv) |
| Vector DB | ChromaDB 1.5.9 |
| App framework | Streamlit 1.58.0 |
| Embedding / ML stack | sentence-transformers 5.6.0, transformers 5.12.1, torch 2.12.1 |
| Data processing | pandas 3.0.3, PyMuPDF 1.27.2.3, Pillow 12.2.0 |

로컬 LLM은 Ollama를 이용하여 실행하였다. 응답 생성 비교에 사용한 모델 구성은 다음과 같다.

| 모델 | 로컬 모델 ID | 앱 파일 | 로컬 저장 크기 |
|---|---|---|---:|
| Qwen 2.5 7B Q4 | qwen2.5:7b | src/app_qwen.py | 약 4.36GB |
| Gemma 2 9B Q4 | gemma2:9b | src/app_gemma.py | 약 5.07GB |
| Llama 3.1 8B Q4 | llama3.1:8b | src/app_llama.py | 약 4.58GB |

그 밖의 로컬 저장 모델은 비교 대상에서 제외하였으며, 기본 비교 범위는 Qwen 2.5 7B, Gemma 2 9B 및 Llama 3.1 8B로 한정하였다.

## 5. 실험 결과

### 5.1 전체 검색 성능

표는 최종 구현을 기준으로 G1~G4의 텍스트, 이미지 및 결합 검색 성능을 비교한 결과이다.

| 비교군 | Text R@1 | Text R@5 | Text R@10 | Text MRR | Image R@1 | Image R@5 | Image R@10 | Image MRR | Both@5 | Both@10 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| G1 Keyword Search | 75.7% | 95.7% | 98.6% | 0.837 | - | - | - | - | - | - |
| G2 Text-only RAG | 81.4% | 95.7% | 100.0% | 0.879 | - | - | - | - | - | - |
| G3 Multimodal RAG | 81.4% | 95.7% | 100.0% | 0.879 | 45.7% | 71.4% | 80.0% | 0.572 | 71.4% | 80.0% |
| G4 Context-aware Multimodal RAG | 85.7% | 95.7% | 100.0% | 0.903 | 48.6% | 77.1% | 87.1% | 0.620 | 77.1% | 87.1% |

G1의 Text Recall@5는 95.7%로 나타났다. 평가 질의에 메뉴명, 설정값 및 기능명과 같은 명시적 기술 용어가 포함된 점이 키워드 검색 결과에 영향을 준 것으로 해석할 수 있다. G2는 Text Recall@1과 Text MRR에서 G1보다 높은 값을 보였다. 이는 본 질의셋에서 임베딩 기반 검색이 키워드 기반 검색보다 정답 텍스트를 상위에 배치하는 데 상대적으로 유리했음을 나타낸다.

G2와 G3의 텍스트 검색 성능은 동일하였다. 두 비교군은 BGE-M3 임베딩 모델, ChromaDB 텍스트 컬렉션, 텍스트 청크 및 상위 k개 검색 절차를 공유한다. G3는 G2의 텍스트 검색기를 변경하지 않고, 해당 검색 결과에 이미지 전용 검색, 페이지 근접도 및 텍스트-이미지 매핑 점수를 추가한 확장 구조이다. 따라서 두 비교군의 Text Recall@k와 Text MRR이 동일한 것은 실험 설계에 따른 결과이다. G3의 목적은 텍스트 검색기의 성능 향상이 아니라 텍스트 근거와 함께 관련 이미지·도식을 검색하는 데 있다.

G3의 Image Recall@5와 Image Recall@10은 각각 71.4%와 80.0%였으며, Image Recall@1과 Image MRR은 각각 45.7%와 0.572였다. BBox를 가중합 요소가 아닌 후보 필터로 사용하고 SigLIP 매핑과 페이지 근접도를 반영한 구성은 이전 파일럿 구성보다 높은 상위 순위 성능을 보였다. 최종 G3에서도 정답 이미지를 1위에 배치한 비율은 절반 미만이었다.

G4에서는 G3보다 이미지 검색 지표가 수치적으로 증가하였다. Image Recall@5는 71.4%에서 77.1%로, Image Recall@10은 80.0%에서 87.1%로 상승하였고, Image MRR은 0.572에서 0.620으로 증가하였다. Both@5와 Both@10도 각각 71.4%에서 77.1%, 80.0%에서 87.1%로 상승하였다. Image Recall@1은 45.7%에서 48.6%로 2.9%p 증가하였다. 이러한 결과는 G4가 모든 질의에서 정답 이미지를 최상위에 배치한 것이 아니라, 일부 정답 후보를 상위 5개 또는 10개 범위로 이동시키고 평균 순위를 높였음을 의미한다. 다만 본 결과에는 통계적 유의성 검정이 포함되지 않았으므로, 수치 증가를 일반적인 우월성으로 해석해서는 안 된다.

### 5.2 G4 개선 사례

정량 지표만으로는 재순위화 과정이 개별 질의에 미친 영향을 확인하기 어렵다. 이에 G3보다 정답 이미지의 순위가 상승한 세 사례를 분석하였다. 이 사례들은 질의 기반 실습 단계 추정과 단계별 페이지·절·핵심어 문맥이 후보 순위에 어떻게 반영되었는지를 보여준다.

Q31은 티치 펜던트의 USB 포트 용도를 묻는 질의이다. 정답 이미지 `page_103_img_0_0.jpeg`는 G3의 8위에서 G4의 3위로 상승하였다. 이 질의는 `티치 펜던트/USB 데이터 관리` 단계로 추정되었으며, USB 포트, 펜던트 및 데이터 가져오기·내보내기 관련 문맥이 재순위화에 반영되었다. 이러한 문맥 점수가 순위 상승에 기여한 것으로 해석할 수 있다.

Q23은 로봇 시스템의 시간을 확인하는 화면 영역을 묻는 질의이다. 정답 이미지 `page_167_img_3_0.jpeg`는 G3의 상위 10개에 포함되지 않았으나 G4에서는 4위에 배치되었다. 질의가 `UI/시스템 정보 확인` 단계로 추정되면서 시스템 정보, 시간 및 화면 영역 관련 문맥이 후보 점수에 반영된 결과로 볼 수 있다.

Q02는 제어기 전원 공급에 필요한 접지 조건을 묻는 질의이다. 정답 이미지 `page_403_img_0_0.jpeg`는 G3의 2위에서 G4의 1위로 상승하였다. 이 질의는 `안전/전원/접지` 단계로 추정되었으며, 접지, 전원 공급, 제어기 및 안전 관련 문맥이 반영되었다.

세 사례에서는 단계 문맥을 적용한 이후 정답 이미지의 순위가 상승하였다. 그러나 사례 분석은 재순위화가 작동한 양상을 설명하기 위한 것이며, 전체 질의에서의 일관된 상위 1위 검색을 의미하지 않는다.

### 5.3 G4 실패 사례

개선 사례와 함께 G4에서 정답 이미지가 상위 10개에 포함되지 않은 사례도 분석하였다. 이 사례들은 페이지 및 절 수준의 문맥만으로는 동일 페이지의 유사 이미지, 세부 화면 단서 및 단계 추정 오류를 충분히 처리하기 어렵다는 점을 보여준다.

Q10은 티치 펜던트에서 현재 관절 각도를 확인하는 메뉴 경로를 묻는 질의이다. G4는 상태 관련 페이지와 핵심어를 반영하였으나, 정답 이미지 `page_332_img_0_0.jpeg`를 상위 10개에 포함하지 못했다. `Status`, `I/O Overview` 및 `joint angle`과 같은 핵심어가 초기 후보 수집 단계에서 정답 이미지를 확보하는 데 충분하지 않았을 가능성이 있다.

Q28은 로봇 큐브 모듈 케이블의 방수 등급을 강화하기 위한 케이블 결합 부품을 묻는 질의이다. G4는 405페이지 주변의 관련 이미지를 상위 후보로 배치하였으나, 정답 이미지 `page_405_img_0_0.jpeg`는 상위 10개에 포함되지 않았다. 이는 동일 페이지의 여러 이미지 가운데 세부 대상을 구분하는 이미지 단위 변별력이 충분하지 않았음을 나타낸다.

Q15는 과거 오류 로그를 추출하는 메뉴 경로를 묻는 질의이다. 이 질의는 `시스템 관리/로그`가 아닌 `UI/시스템 정보 확인` 단계로 추정되었고, 정답 이미지 `page_340_img_0_0.jpeg`는 상위 10개에 포함되지 않았다. 이 사례는 단계 추정 오류가 후속 재순위화 결과에 영향을 줄 수 있음을 보여준다.

실패 사례를 종합하면, BBox 후보 필터는 공간적으로 먼 이미지를 제외하지만 필터를 통과한 동일 페이지의 유사 이미지를 직접 구분하지는 않는다. 현재 후보 순위는 SigLIP 의미 유사도와 페이지·절 문맥에 주로 의존하므로 화면 내부의 작은 차이와 이미지 순서를 충분히 반영하지 못한다. 향후에는 이미지 캡션, BBox 주변의 국소 텍스트, 이미지 순서 및 세분화된 단계 라벨을 추가로 검토할 필요가 있다.

## 6. 응답 품질 평가 결과

검색 성능과 로컬 LLM 기반 응답 품질을 서로 구분하여 평가하였다. G2, G3 및 G4 조건에서 Qwen, Gemma 및 Llama의 응답을 생성하였으며, 70개 질의에 대한 총 630개 응답을 평가하였다.

RAG 평가는 검색 정확도뿐 아니라 문맥 관련성, 응답 충실성 및 응답 관련성을 구분하여 다룰 필요가 있으므로[20], [21], 응답 품질은 검색 성능과 별도로 평가하였다. 다음 다섯 기준을 사용하였다.

1. 정확성: 정답 텍스트의 핵심 내용과 일치하는가?
2. 구체성: 메뉴 경로, 버튼명, 설정값, 절차가 충분히 구체적인가?
3. 실습 단계 적합성: 질의의 실습 단계에 부합하는 안내를 제공하는가?
4. 안전성: 위험하거나 잘못된 로봇 조작을 안내하지 않는가?
5. 이해 용이성: 초보 학습자가 이해하기 쉬운 표현으로 설명하는가?

각 항목을 1점에서 5점으로 산정하고, 평균 점수를 기준으로 모델 및 비교군별 응답 품질을 분석하였다. 전체 630개 응답은 정답 핵심어 일치, 의미 유사도 및 안전성·가독성 관련 규칙을 이용한 규칙 기반 루브릭 평가로 처리하였다.

| 비교군 | 모델 | 평가 수 | 평균 점수 | O | △ | X |
|---|---|---:|---:|---:|---:|---:|
| G2 Text-only RAG | Qwen | 70 | 4.05 | 49 | 13 | 8 |
| G2 Text-only RAG | Gemma | 70 | 3.59 | 27 | 31 | 12 |
| G2 Text-only RAG | Llama | 70 | 3.62 | 24 | 33 | 13 |
| G3 Multimodal RAG | Qwen | 70 | 4.01 | 47 | 15 | 8 |
| G3 Multimodal RAG | Gemma | 70 | 3.56 | 27 | 29 | 14 |
| G3 Multimodal RAG | Llama | 70 | 3.60 | 28 | 27 | 15 |
| G4 Context-aware Multimodal RAG | Qwen | 70 | 3.99 | 47 | 14 | 9 |
| G4 Context-aware Multimodal RAG | Gemma | 70 | 3.59 | 27 | 31 | 12 |
| G4 Context-aware Multimodal RAG | Llama | 70 | 3.62 | 31 | 26 | 13 |

Qwen의 평균 점수는 세 비교군에서 다른 두 모델보다 높았다. 그러나 생성 응답 품질에서 G4의 일관된 향상은 관찰되지 않았다. Qwen의 평균 점수는 G2 4.05점, G3 4.01점, G4 3.99점으로 소폭 감소하였다. Gemma는 G3의 3.56점에서 G4의 3.59점으로, Llama는 3.60점에서 3.62점으로 소폭 증가하였다.

이 결과는 검색 지표의 수치 증가가 생성 응답 품질의 향상으로 직접 이어지지 않았음을 보여준다. 생성 응답은 검색 근거의 변화, 질의 기반 단계 추정 및 로컬 LLM의 생성 특성에 함께 영향을 받는다. 이에 따라 본 연구의 기여는 검색 단계의 제한적 개선으로 해석하는 것이 타당하다. 본 응답 품질 평가는 규칙 기반 결과이므로 실제 사용자 또는 전문가의 판단을 대체하지 않으며, 교육적 효과를 주장하는 근거로 사용하지 않는다.

## 7. 논의

텍스트 검색은 G1에서도 높은 Text Recall@5를 보였고, G2와 G3의 Text Recall@10은 100.0%였다. 반면 G3의 Image Recall@1은 45.7%였다. 다만 텍스트에는 완화된 관련성 기준을, 이미지에는 엄격한 파일명 일치 기준을 적용하였으므로 두 지표의 절대값을 직접 비교하여 이미지 검색이 더 어렵다고 단정할 수는 없다. 그럼에도 엄격한 기준에서 정답 이미지를 상위 1위에 배치한 비율이 절반 미만이라는 결과는 이미지 순위화가 여전히 주요한 개선 대상임을 보여준다.

G4의 상황 인지형 재순위화는 G3보다 높은 Image Recall@5, Image Recall@10 및 Image MRR을 보였다. 단계와 관련된 페이지 범위 및 핵심어가 명확한 일부 사례에서는 정답 이미지 순위가 상승하였다. 그러나 Image Recall@1은 48.6%였으며, 통계적 유의성 및 외부 데이터 일반화도 검증되지 않았다. 따라서 G4는 하나의 정답 이미지를 안정적으로 선택하는 방법보다 관련 후보군의 순위를 조정하는 내부 파일럿 방법으로 해석하는 것이 적절하다.

G4는 페이지 및 절 수준의 문맥을 반영하지만, 동일 페이지에 여러 이미지가 존재하거나 동일 절에 유사한 설정 화면이 포함된 경우에는 정확한 이미지를 구분하지 못하였다. BBox는 전처리 단계의 후보 게이트이므로 필터를 통과한 유사 이미지를 직접 구별하지 않는다. 향후 연구에서는 BBox 주변의 국소 텍스트 연결, 이미지 단위 캡션, 이미지 순서 및 세분화된 실습 단계 분류를 검토할 필요가 있다.

응답 품질 평가에서 G4-Qwen의 평균 점수는 3.99점으로 G4 조건의 세 모델 중 가장 높았으나, G2-Qwen과 G3-Qwen보다는 낮았다. 이는 7B급 양자화 모델을 이용한 응답 생성의 가능성을 제한적으로 보여주지만, 검색 지표의 향상이 생성 품질의 향상으로 일관되게 연결되지는 않았음을 의미한다. 따라서 본 연구의 핵심 기여는 생성 품질보다 검색 근거와 이미지 후보 순위의 개선에 두어야 한다.

## 8. 결론

본 연구는 협동 로봇 실습을 위한 상황 인지형 멀티모달 RAG 프레임워크를 제안하고, 협동 로봇 실습 매뉴얼에서 구성한 70개 질의를 이용하여 검색 성능을 평가하였다. 텍스트 기반 RAG는 대상 매뉴얼의 텍스트 검색에서 높은 Recall@k를 보였으며, G3는 텍스트 검색 결과에 이미지·도식 검색 신호를 결합하였다.

G4는 질의 기반 실습 단계 추정과 단계별 문맥 맵을 이용하여 G3의 후보를 재순위화하였다. 그 결과 Image Recall@5는 71.4%에서 77.1%로, Image Recall@10은 80.0%에서 87.1%로, Image MRR은 0.572에서 0.620으로 증가하였다. 그러나 Image Recall@1은 48.6%로 절반 미만이었으며, 동일 데이터에서 가중치 선택과 최종 평가가 수행되었다. 따라서 본 연구의 결과는 이미지 검색 문제의 해결이 아니라 내부 파일럿 데이터에서 관련 이미지 후보의 순위가 개선된 것으로 제한하여 해석해야 한다.

이 결과는 텍스트, 이미지 및 절차 정보가 함께 사용되는 협동 로봇 실습 매뉴얼에서 단계 문맥을 반영한 멀티모달 재순위화의 적용 가능성을 보여준다. 다만 응답 품질은 일관되게 향상되지 않았고, 독립 데이터와 실제 8GB RAM급 장비에서의 검증도 수행되지 않았다. 향후에는 이미지 단위 변별력을 보완하고, 프롬프트와 근거 구성 방식을 개선하며, 별도 데이터와 실제 학습자 또는 전문가를 대상으로 추가 검증할 필요가 있다.

## 9. 투고 전 보완 사항

본 초안은 검색 성능과 규칙 기반 응답 품질 평가 결과를 반영하였다. 투고 원고로 정리하기 위해서는 다음 항목을 추가로 보완해야 한다.

1. 관련 연구 참고문헌을 IEEE 양식으로 정리해야 한다.
2. 완화된 텍스트 평가와 엄격한 파일명 일치 기반 이미지 평가의 차이를 영문 원고에서도 명확히 유지해야 한다.
3. 엄격한 텍스트 평가는 본 실험에 추가하지 않고, 필요한 경우 보조 분석 또는 부록 후보로 검토한다.
4. G4 단계 추정과 문맥 맵 구축 과정의 객관성을 구체적으로 설명해야 한다.
5. 가중치 선택 결과를 내부 파일럿으로 명시하고, 독립 홀드아웃 또는 추가 매뉴얼 기반 외부 검증을 수행해야 한다.
6. 8GB RAM급 제한 환경은 설계 목표로 명확히 제한해 서술했으며, 영문화 과정에서도 실측 검증 결과로 오해되지 않게 유지해야 한다.
7. 영문 SCIE 원고 형식에 맞게 문체와 참고문헌 표기를 정리해야 한다.

## 10. 참고문헌

[1] A. Djuric, J. L. Rickli, V. M. Jovanovic, and D. Foster, "Hands-on learning environment and educational curriculum on collaborative robotics," in Proc. 2017 ASEE Annu. Conf. Expo., Columbus, OH, USA, 2017, pp. 1-15.

[2] V. Villani, F. Pini, F. Leali, and C. Secchi, "Survey on human-robot collaboration in industrial settings: Safety, intuitive interfaces and applications," Mechatronics, vol. 55, pp. 248-266, Nov. 2018, doi: 10.1016/j.mechatronics.2018.02.009.

[3] Robots and Robotic Devices--Collaborative Robots, ISO/TS 15066:2016, International Organization for Standardization, Geneva, Switzerland, 2016.

[4] P. Lewis et al., "Retrieval-augmented generation for knowledge-intensive NLP tasks," in Advances in Neural Information Processing Systems, vol. 33, 2020, pp. 9459-9474.

[5] G. Izacard and E. Grave, "Leveraging passage retrieval with generative models for open domain question answering," in Proc. 16th Conf. Eur. Chapter Assoc. Comput. Linguistics, 2021, pp. 874-880, doi: 10.18653/v1/2021.eacl-main.74.

[6] S. Borgeaud et al., "Improving language models by retrieving from trillions of tokens," in Proc. 39th Int. Conf. Mach. Learn., vol. 162, 2022, pp. 2206-2240.

[7] V. Karpukhin et al., "Dense passage retrieval for open-domain question answering," in Proc. 2020 Conf. Empirical Methods Natural Language Process., 2020, pp. 6769-6781, doi: 10.18653/v1/2020.emnlp-main.550.

[8] S. Robertson and H. Zaragoza, "The probabilistic relevance framework: BM25 and beyond," Found. Trends Inf. Retr., vol. 3, no. 4, pp. 333-389, 2009, doi: 10.1561/1500000019.

[9] N. Reimers and I. Gurevych, "Sentence-BERT: Sentence embeddings using Siamese BERT-networks," in Proc. 2019 Conf. Empirical Methods Natural Language Process. and 9th Int. Joint Conf. Natural Language Process., 2019, pp. 3982-3992, doi: 10.18653/v1/D19-1410.

[10] J. Chen, S. Xiao, P. Zhang, K. Luo, D. Lian, and Z. Liu, "M3-Embedding: Multi-linguality, multi-functionality, multi-granularity text embeddings through self-knowledge distillation," in Findings Assoc. Comput. Linguistics: ACL 2024, 2024, pp. 2318-2335, doi: 10.18653/v1/2024.findings-acl.137.

[11] Y. Gao et al., "Retrieval-augmented generation for large language models: A survey," arXiv:2312.10997, 2023.

[12] A. Radford et al., "Learning transferable visual models from natural language supervision," in Proc. 38th Int. Conf. Mach. Learn., vol. 139, 2021, pp. 8748-8763.

[13] C. Jia et al., "Scaling up visual and vision-language representation learning with noisy text supervision," in Proc. 38th Int. Conf. Mach. Learn., vol. 139, 2021, pp. 4904-4916.

[14] J. Li, D. Li, C. Xiong, and S. Hoi, "BLIP: Bootstrapping language-image pre-training for unified vision-language understanding and generation," in Proc. 39th Int. Conf. Mach. Learn., vol. 162, 2022, pp. 12888-12900.

[15] X. Zhai, B. Mustafa, A. Kolesnikov, and L. Beyer, "Sigmoid loss for language image pre-training," in Proc. IEEE/CVF Int. Conf. Comput. Vis., 2023, pp. 11975-11986.

[16] W. Chen, H. Hu, X. Chen, P. Verga, and W. W. Cohen, "MuRAG: Multimodal retrieval-augmented generator for open question answering over images and text," in Proc. 2022 Conf. Empirical Methods Natural Language Process., 2022, pp. 5558-5570, doi: 10.18653/v1/2022.emnlp-main.375.

[17] Z. Hu et al., "REVEAL: Retrieval-augmented visual-language pre-training with multi-source multimodal knowledge memory," in Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit., 2023, pp. 23369-23379.

[18] M. Yasunaga et al., "Retrieval-augmented multimodal language modeling," in Proc. 40th Int. Conf. Mach. Learn., vol. 202, 2023, pp. 39755-39769.

[19] Y. Xu, M. Li, L. Cui, S. Huang, F. Wei, and M. Zhou, "LayoutLM: Pre-training of text and layout for document image understanding," in Proc. 26th ACM SIGKDD Int. Conf. Knowl. Discovery Data Mining, 2020, pp. 1192-1200, doi: 10.1145/3394486.3403172.

[20] S. Es, J. James, L. Espinosa-Anke, and S. Schockaert, "RAGAs: Automated evaluation of retrieval augmented generation," in Proc. 18th Conf. Eur. Chapter Assoc. Comput. Linguistics: Syst. Demonstrations, 2024, pp. 150-158, doi: 10.18653/v1/2024.eacl-demo.16.

[21] J. Saad-Falcon, O. Khattab, C. Potts, and M. Zaharia, "ARES: An automated evaluation framework for retrieval-augmented generation systems," in Proc. 2024 Conf. North Amer. Chapter Assoc. Comput. Linguistics: Human Language Technol., 2024, pp. 338-354, doi: 10.18653/v1/2024.naacl-long.20.

[22] Qwen Team, "Qwen2.5 technical report," arXiv:2412.15115, 2024.

[23] Gemma Team et al., "Gemma 2: Improving open language models at a practical size," arXiv:2408.00118, 2024.

[24] A. Grattafiori et al., "The Llama 3 herd of models," arXiv:2407.21783, 2024.

[25] T. Dettmers, A. Pagnoni, A. Holtzman, and L. Zettlemoyer, "QLoRA: Efficient finetuning of quantized LLMs," in Advances in Neural Information Processing Systems, vol. 36, 2023.

[26] E. Frantar, S. Ashkboos, T. Hoefler, and D. Alistarh, "GPTQ: Accurate post-training quantization for generative pre-trained transformers," in Proc. 11th Int. Conf. Learn. Representations, 2023.

[27] J. Lin et al., "AWQ: Activation-aware weight quantization for on-device LLM compression and acceleration," Proc. Mach. Learn. Syst., vol. 6, pp. 87-100, 2024.

[28] Chroma, "Chroma documentation: Introduction." Accessed: Jul. 25, 2026. [Online]. Available: https://docs.trychroma.com/docs/overview/introduction

[29] E. M. Voorhees and D. M. Tice, "The TREC-8 question answering track evaluation," in Proc. 8th Text REtrieval Conf., NIST Special Publication 500-246, 2000, pp. 83-105.

[30] Doosan Robotics, "DART-Platform manual," User Manual, ver. 3.6.0. Accessed: Jul. 25, 2026. [Online]. Available: https://manual.doosanrobotics.com/en/user-manual/3.6.0/1-m-h-series/part-6-dart-platform-manual

## 11. 논문에 사용할 핵심 파일

| 용도 | 파일 |
|---|---|
| 최종 정리본 | `SCIE용/18_paper_ready_summary.md` |
| 70개 질의셋 | `SCIE용/excel/03_question_set_70.xlsx` |
| 비교군 정의 | `SCIE용/05_experiment_groups.md` |
| 평가 지표 | `SCIE용/06_metrics.md` |
| G4 context map | `SCIE용/excel/11_stage_context_map_manual.xlsx` |
| G4 최종 결과 | `SCIE용/30_g4_auto_results.md` |
| G4 단계 추정 결과 | `SCIE용/29_stage_classifier_results.md`, `SCIE용/excel/29_stage_classifier_eval.xlsx` |
| G1/G2/G3/G4 비교 결과 | `SCIE용/15_g1_g2_g3_g4_results.md` |
| G4 사례 분석 | `SCIE용/16_g4_case_analysis.md` |
| 응답 품질 평가 기준 | `SCIE용/17_response_quality_eval_criteria.md` |
| 응답 품질 평가 템플릿 | `SCIE용/excel/17_response_quality_eval_template.xlsx` |
| 응답 품질 평가 결과 | `SCIE용/22_response_quality_eval_results.md`, `SCIE용/excel/22_response_quality_eval_results.xlsx` |
| 논문 표/그림 캡션 | `SCIE용/32_tables_figures_captions.md` |
| G4 context map 구축 절차 | `SCIE용/33_context_map_protocol.md` |
| IEEE Access 준비 체크리스트 | `SCIE용/34_ieee_access_readiness_checklist.md` |
| 텍스트 평가 기준 정책 | `SCIE용/35_text_evaluation_policy.md` |
| 시스템 전체 설명서 | `SCIE용/36_system_full_explanation.md` |
